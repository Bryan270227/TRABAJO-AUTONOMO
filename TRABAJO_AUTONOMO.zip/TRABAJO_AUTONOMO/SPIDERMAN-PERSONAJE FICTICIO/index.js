const express = require("express");
const app=express();
const port = 3000;

app.use(express.json());

app.get('/spider', (req,res)=>{
    res.send('SPIDERMAN');
   });
   
  app.listen(port, ()=>{
    console.log('Servidor escuchando en el puerto ' + port);
   });

   app.get('/spider/info', (req,res)=>{
    res.send('<h1>INFORMACIÓN DE SPIDERMAN</h1>');
   });

   app.get('/spider/info/mas', (req,res)=>{
    res.send('<h1>VILLANOS</h1>');
   });


   

